import { getUsers, createUser } from '../api.js';

export function renderRegister() {
    const app = document.getElementById('app');
    app.innerHTML = `
        <h2>Registrarse</h2>
        <form id="register-form">
            <input type="text" name="username" placeholder="Usuario" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <button type="submit">Registrarse</button>
        </form>
    `;

    document.getElementById('register-form').onsubmit = async (e) => {
        e.preventDefault();
        const username = e.target.username.value.trim();
        const password = e.target.password.value;

        // Trae todos los usuarios
        const users = await getUsers();
        // Valida si ya existe el nombre de usuario
        if (users.some(u => u.username === username)) {
            alert('El nombre de usuario ya está en uso. Elige otro.');
            return;
        }

        await createUser({ username, password, role: 'visitor' });
        alert('¡Registro exitoso! Ahora puedes iniciar sesión.');
        window.location.hash = '/login';
    };
}