import { login } from '../auth.js';
// Función para renderizar la página de inicio de sesión
export function renderLogin() {
    const app = document.getElementById('app');
    app.innerHTML = `
        <h2>Iniciar sesión</h2>
        <form id="login-form">
            <input type="text" name="username" placeholder="Usuario" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <button type="submit">Entrar</button>
        </form>
    `;
    document.getElementById('login-form').onsubmit = async (e) => {
        e.preventDefault();
        const username = e.target.username.value;
        const password = e.target.password.value;
        const ok = await login(username, password);
        if (ok) window.location.hash = '/dashboard';
        else alert('Credenciales incorrectas');
    };
}